﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Misc.SendinBlue.Models
{
    /// <summary>
    /// Represents SMS search model
    /// </summary>
    public partial class SmsSearchModel : BaseSearchModel
    {
    }
}