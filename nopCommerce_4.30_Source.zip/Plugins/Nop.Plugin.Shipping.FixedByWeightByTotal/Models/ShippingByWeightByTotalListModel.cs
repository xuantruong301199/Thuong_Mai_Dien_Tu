﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Shipping.FixedByWeightByTotal.Models
{
    public partial class ShippingByWeightByTotalListModel : BasePagedListModel<ShippingByWeightByTotalModel>
    {
    }
}
